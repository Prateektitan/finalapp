import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:auto_size_text/auto_size_text.dart';
import 'package:flutter_app/Screens/BottomNavScreen.dart';
import 'package:flutter_app/Screens/SignInScreen.dart';
import 'package:flutter_app/Components/Constants.dart';

class LoginScreen extends StatefulWidget {
  @override
  _LoginScreenState createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _formKey1 = GlobalKey<FormState>();
  late String User_email, _User_Password;

  final Shader linearGradient = LinearGradient(
    colors: <Color>[Constants.highlight_medium, Constants.primary_light],
  ).createShader(Rect.fromLTWH(0.0, 0.0, 200.0, 70.0));

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: true,
      body: Center(
        child: Container(
          width: MediaQuery.of(context).size.width,
          height: MediaQuery.of(context).size.height,
          child: SingleChildScrollView(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Container(
                  margin: EdgeInsets.only(top: 40),
                  //height: MediaQuery.of(context).size.height*0.25,
                  width: MediaQuery.of(context).size.width,
                  padding: EdgeInsets.symmetric(horizontal: 20),
                  child: Align(
                    alignment: Alignment.centerLeft,
                    child: AutoSizeText(
                      'Welcome',
                      style: GoogleFonts.montserrat(
                          fontWeight: FontWeight.bold,
                          fontSize: 50,
                          foreground: Paint()..shader = linearGradient),
                      maxLines: 1,
                      maxFontSize: 80,
                      minFontSize: 24,
                    ),
                  ),
                ),
                Container(
                  padding: EdgeInsets.only(top: 10, left: 30, right: 30),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: <Widget>[
                      Form(
                        key: _formKey1,
                        child: Column(
                          children: <Widget>[
                            TextFormField(
                              validator: (value) {
                                return null;
                              },
                              decoration: InputDecoration(
                                labelText: 'EMAIL',
                                labelStyle: GoogleFonts.montserrat(
                                    fontWeight: FontWeight.bold,
                                    foreground: Paint()
                                      ..shader = linearGradient),
                                hintText: 'abc@xyz.com',
                                hintStyle: GoogleFonts.montserrat(),
                                focusedBorder: UnderlineInputBorder(
                                  borderSide: BorderSide(
                                    color: Colors.green,
                                  ),
                                ),
                              ),
                            ),
                            SizedBox(
                              height: 10,
                            ),
                            TextFormField(
                              validator: (value) {
                                //place validations here
                                return null;
                              },
                              decoration: InputDecoration(
                                labelText: 'PASSWORD',
                                labelStyle: GoogleFonts.montserrat(
                                    foreground: Paint()
                                      ..shader = linearGradient,
                                    fontWeight: FontWeight.bold),
                                focusedBorder: UnderlineInputBorder(
                                  borderSide: BorderSide(
                                    color: Colors.green,
                                  ),
                                ),
                              ),
                              obscureText: true,
                            ),
                          ],
                        ),
                      ),
                      SizedBox(
                        height: 10,
                      ),
                      Container(
                        alignment: Alignment.centerRight,
                        padding: EdgeInsets.only(left: 30, top: 15),
                        child: InkWell(
                          /*
                                onTap: (){
                                  Navigator.push(context,
                                    MaterialPageRoute(builder: (context) => reset()),
                                  );
                                },
                                 */
                          child: Text(
                            'Forgot Password?',
                            style: GoogleFonts.montserrat(
                                foreground: Paint()..shader = linearGradient,
                                fontWeight: FontWeight.bold,
                                decoration: TextDecoration.underline),
                          ),
                        ),
                      ),
                      SizedBox(
                        height: 20,
                      ),
                      GestureDetector(
                        onTap: () {
                          Navigator.pushReplacement(
                              context,
                              CupertinoPageRoute(
                                  builder: (context) => BottomNavScreen()));
                        },
                        child: Container(
                          height: 40,
                          child: Material(
                            color: Constants.primary_dark,
                            borderRadius: BorderRadius.circular(20.0),
                            shadowColor: Constants.primary_light,
                            elevation: 7.0,
                            child: Center(
                              child: Text(
                                'Login',
                                style: GoogleFonts.montserrat(
                                    fontWeight: FontWeight.bold,
                                    fontSize: 20,
                                    color: Colors.white),
                              ),
                            ),
                          ),
                        ),
                      ),
                      SizedBox(height: 20),
                      Text(
                        'More ways to Sign in',
                        style: GoogleFonts.montserrat(
                            foreground: Paint()..shader = linearGradient,
                            fontSize: 16,
                            fontWeight: FontWeight.bold),
                      ),
                      GestureDetector(
                        onTap: () {
                          Navigator.pushReplacement(
                              context,
                              CupertinoPageRoute(
                                  builder: (context) => BottomNavScreen()));
                        },
                        child: Container(
                          height: 40,
                          margin: EdgeInsets.only(top: 20),
                          child: Material(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(20.0),
                            shadowColor: Colors.black,
                            elevation: 7.0,
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                CircleAvatar(
                                  backgroundColor: Colors.white,
                                  radius: 30,
                                  child: Image.asset(
                                    'Assets/Images/google.png',
                                    height: 30,
                                    width: 30,
                                    fit: BoxFit.fill,
                                  ),
                                ),
                                Text(
                                  'Google Sign In',
                                  style: GoogleFonts.montserrat(
                                      foreground: Paint()
                                        ..shader = linearGradient,
                                      fontSize: 16,
                                      fontWeight: FontWeight.bold),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                      GestureDetector(
                        onTap: () {
                          Navigator.pushReplacement(
                              context,
                              CupertinoPageRoute(
                                  builder: (context) => BottomNavScreen()));
                        },
                        child: Container(
                          height: 40,
                          margin: EdgeInsets.only(top: 20),
                          child: Material(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(20.0),
                            shadowColor: Colors.black,
                            elevation: 7.0,
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                CircleAvatar(
                                  backgroundColor: Colors.white,
                                  radius: 30,
                                  child: Image.asset(
                                    'Assets/Images/facebook.png',
                                    height: 30,
                                    width: 30,
                                    fit: BoxFit.fill,
                                  ),
                                ),
                                Text(
                                  'Facebook Sign In',
                                  style: GoogleFonts.montserrat(
                                      foreground: Paint()
                                        ..shader = linearGradient,
                                      fontSize: 16,
                                      fontWeight: FontWeight.bold),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                      Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: <Widget>[
                          Container(
                            alignment: Alignment.center,
                            padding: EdgeInsets.only(left: 20, top: 15),
                            child: Text(
                              "New User?",
                              style: GoogleFonts.montserrat(
                                  fontWeight: FontWeight.bold),
                            ),
                          ),
                          SizedBox(
                            width: 5,
                          ),
                          Container(
                            alignment: Alignment.center,
                            padding: EdgeInsets.only(top: 15),
                            child: InkWell(
                              onTap: () {
                                Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                      builder: (context) => SignUpPage()),
                                );
                              },
                              child: Text(
                                'Register',
                                style: GoogleFonts.montserrat(
                                    foreground: Paint()
                                      ..shader = linearGradient,
                                    fontWeight: FontWeight.bold,
                                    decoration: TextDecoration.underline),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
