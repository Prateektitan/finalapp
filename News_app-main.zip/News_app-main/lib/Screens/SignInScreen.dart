import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:auto_size_text/auto_size_text.dart';
import 'package:flutter_app/Components/Constants.dart';
import 'package:flutter_app/Screens/LoginScreen.dart';

class SignUpPage extends StatefulWidget {
  @override
  _SignUpPageState createState() => _SignUpPageState();
}

class _SignUpPageState extends State<SignUpPage> {
  final _formKey = GlobalKey<FormState>();
  late String User_email, _User_Password;

  final Shader linearGradient = LinearGradient(
    colors: <Color>[Constants.highlight_medium, Constants.primary_light],
  ).createShader(Rect.fromLTWH(0.0, 0.0, 200.0, 70.0));

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: true,
      body: SingleChildScrollView(
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Container(
                margin: EdgeInsets.only(top: 40),
                width: MediaQuery.of(context).size.width,
                padding: EdgeInsets.symmetric(horizontal: 20),
                child: AutoSizeText(
                  'Sign In',
                  style: GoogleFonts.montserrat(
                      foreground: Paint()..shader = linearGradient,
                      fontWeight: FontWeight.bold,
                      fontSize: 50),
                ),
              ),
              Container(
                padding: EdgeInsets.only(top: 0, left: 30),
                child: Form(
                  key: _formKey,
                  child: Column(
                    children: <Widget>[
                      TextFormField(
                        decoration: InputDecoration(
                          labelText: 'EMAIL',
                          labelStyle: GoogleFonts.montserrat(
                              foreground: Paint()..shader = linearGradient,
                              fontWeight: FontWeight.bold),
                          hintText: 'abc@xyz.com',
                          hintStyle: GoogleFonts.montserrat(),
                          focusedBorder: UnderlineInputBorder(
                            borderSide: BorderSide(
                              color: Colors.green,
                            ),
                          ),
                        ),
                      ),
                      SizedBox(
                        height: 10,
                      ),
                      TextFormField(
                        decoration: InputDecoration(
                          labelText: 'PASSWORD',
                          labelStyle: GoogleFonts.montserrat(
                              foreground: Paint()..shader = linearGradient,
                              fontWeight: FontWeight.bold),
                          hintStyle: GoogleFonts.montserrat(),
                          hintText: 'min 8 digits',
                          focusedBorder: UnderlineInputBorder(
                            borderSide: BorderSide(
                              color: Colors.green,
                            ),
                          ),
                        ),
                        obscureText: true,
                      ),
                      SizedBox(
                        height: 10,
                      ),
                      TextFormField(
                        decoration: InputDecoration(
                          labelText: 'CONFIRM PASSWORD',
                          labelStyle: GoogleFonts.montserrat(
                              foreground: Paint()..shader = linearGradient,
                              fontWeight: FontWeight.bold),
                          hintStyle: GoogleFonts.montserrat(),
                          hintText: '',
                          focusedBorder: UnderlineInputBorder(
                            borderSide: BorderSide(
                              color: Colors.green,
                            ),
                          ),
                        ),
                        obscureText: true,
                      ),
                      SizedBox(
                        height: 10,
                      ),
                      TextFormField(
                        decoration: InputDecoration(
                          labelText: 'Full Name',
                          labelStyle: GoogleFonts.montserrat(
                              foreground: Paint()..shader = linearGradient,
                              fontWeight: FontWeight.bold),
                          hintStyle: GoogleFonts.montserrat(),
                          focusedBorder: UnderlineInputBorder(
                            borderSide: BorderSide(
                              color: Colors.green,
                            ),
                          ),
                        ),
                        obscureText: false,
                      ),
                      SizedBox(
                        height: 10,
                      ),
                    ],
                  ),
                ),
              ),
              SizedBox(
                height: 30,
              ),
              GestureDetector(
                onTap: () async {},
                child: Container(
                  alignment: Alignment.center,
                  padding: EdgeInsets.only(left: 20, right: 20, top: 0),
                  height: 40,
                  child: Material(
                    color: Constants.primary_dark,
                    borderRadius: BorderRadius.circular(20.0),
                    shadowColor: Constants.primary_light,
                    elevation: 7.0,
                    //place login here
                    child: Center(
                      child: Text(
                        'Sign Up',
                        style: GoogleFonts.montserrat(
                            fontWeight: FontWeight.bold,
                            fontSize: 20,
                            color: Colors.white),
                      ),
                    ),
                  ),
                ),
              ),
              SizedBox(
                height: 30,
              ),
              GestureDetector(
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => LoginScreen()),
                  );
                },
                child: Container(
                  alignment: Alignment.center,
                  padding: EdgeInsets.only(left: 20, right: 20, top: 0),
                  height: 40,
                  child: Material(
                    color: Constants.primary_dark,
                    borderRadius: BorderRadius.circular(20.0),
                    shadowColor: Constants.primary_light,
                    elevation: 7.0,
                    child: Center(
                      child: Text(
                        'Back',
                        style: GoogleFonts.montserrat(
                            fontWeight: FontWeight.bold,
                            fontSize: 20,
                            color: Colors.white),
                      ),
                    ),
                  ),
                ),
              ),
              SizedBox(
                height: 10,
              ),
            ],
          ),
        ),
      ),
    );
  }
}
